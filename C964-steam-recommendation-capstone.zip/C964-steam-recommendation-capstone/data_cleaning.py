# Name: Cole Linke
# Course: Computer Science Capstone
# Application: Steam Game Recommender System

# Cleans steam game data.

# Link to steam games dataset:
# https://www.kaggle.com/datasets/fronkongames/steam-games-dataset

# 1. Click the link above to download the JSON file.
# 2. Place the JSON file in the same directory as this script.
# 3. Run this script to generate a cleaned csv version of the dataset.

#------------------------------------------------------------------------------
# Import necessary libraries
#------------------------------------------------------------------------------

import pandas as pd
from pathlib import Path
import numpy as np

#-------------------------------------------------------
# Configuration
#-------------------------------------------------------

JSON_PATH = Path("games.json")
OUTPUT_CSV = Path("steam_games_cleaned.csv")

# Column remapping
COLUMN_NAME_DICT = {
"name": "Name",
"release_date": "Release date",
"required_age": "Required age",
"price": "Price",
"dlc_count": "DLC count",
"detailed_description": "Detailed description",
"about_the_game": "About the game",
"short_description": "Short description",
"reviews": "Reviews",
"header_image": "Header image",
"website": "Website",
"support_url": "Support url",
"support_email": "Support email",
"windows": "Windows",
"mac": "Mac",
"linux": "Linux",
"metacritic_score": "Metacritic score",
"metacritic_url": "Metacritic url",
"achievements": "Achievements",
"recommendations": "Recommendations",
"notes": "Notes",
"supported_languages": "Supported languages",
"full_audio_languages": "Full audio languages",
"packages": "Packages",
"developers": "Developers",
"publishers": "Publishers",
"categories": "Categories",
"genres": "Genres",
"screenshots": "Screenshots",
"movies": "Movies",
"user_score": "User score",
"score_rank": "Score rank",
"positive": "Positive",
"negative": "Negative",
"estimated_owners": "Estimated owners",
"average_playtime_forever": "Average playtime forever",
"average_playtime_2weeks": "Average playtime two weeks",
"median_playtime_forever": "Median playtime forever",
"median_playtime_2weeks": "Median playtime two weeks",
"peak_ccu": "Peak CCU",
"tags": "Tags"
}

# Columns to keep 
KEEP_COLS = [
    "AppID",
    "Name",
    "Short description",
    "Tags",
    "Genres",
    "Positive",
    "Negative",
    "Metacritic score",
    "Estimated owners",
]

TEXT_COLS = ["Name", "Short description", "Genres", "Tags"]
NUM_COLS = ["Positive", "Negative", "Metacritic score"]

#-------------------------------------------------------
# Helper Functions
#-------------------------------------------------------

def convert_dict_to_string(value):
    
    # Convert dict keys to comma-separated string
    if not value:
        return np.nan
    return ",".join(value.keys())

def load_and_convert_json(json_path = Path) -> pd.DataFrame:
    
    # Read the JSON file
    df = pd.read_json(json_path).T
    df["AppID"] = df.index
    df.rename(columns=COLUMN_NAME_DICT, inplace=True)

    # Convert the dict/array columns
    for col in df.columns:
        df[col] = df[col].apply(
            lambda v: convert_dict_to_string(v) if isinstance(v, dict)
            else ",".join(v) if isinstance(v, list) and v and all(isinstance(x, str) for x in v)
            else np.nan if isinstance(v, list) and not v
            else v
    )

    df = df.reset_index(drop=True)
    return df

#-------------------------------------------------------
# Data Cleaning Function
#-------------------------------------------------------

def clean_data(df: pd.DataFrame) -> pd.DataFrame:

    df = df.copy()

    # Remove rows with missing/blank names
    df["Name"] = df["Name"].fillna("").astype(str).str.strip()
    df = df[df["Name"] != ""]

    # Fill missing numerical values with 0
    for col in NUM_COLS:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

    # Fill missing text values with empty strings
    for col in TEXT_COLS:
        df[col] = df[col].fillna("").astype(str)

    # Drop rows that have no content
    df = df[~(
        (df["Short description"].str.strip() == "") &
        (df["Genres"].str.strip() == "") &
        (df["Tags"].str.strip() == "")
    )]

    return df

#-------------------------------------------------------
# Main Execution
#-------------------------------------------------------

def main():

    # Convert JSON to DataFrame
    df_converted = load_and_convert_json(JSON_PATH)

    # Keep only relevant columns
    df_trimmed = df_converted[KEEP_COLS].copy()

    # Clean the data
    df_clean = clean_data(df_trimmed)

    # Save cleaned data to CSV
    df_clean.to_csv(OUTPUT_CSV, index=False)

    # Print summary
    out_mb = OUTPUT_CSV.stat().st_size / (1024 * 1024)
    print(f"Output file size: {out_mb:.2f} MB")

if __name__ == "__main__":
    main()
